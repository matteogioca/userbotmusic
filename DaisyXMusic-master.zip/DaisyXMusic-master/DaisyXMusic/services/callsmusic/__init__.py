from DaisyXMusic.services.callsmusic import queues
from DaisyXMusic.services.callsmusic.callsmusic import pytgcalls, run
